# Modulo4
Troy de acceso remoto
      Ip para equipos
            
            VICTIMA 192.168.222.4  Puerto: 6660 (yo queria el 666 :( )
            ATACANTE 192.168.222.9
            C&C   192.168.222.13

#Requerimientos
- .5 puntos. Módulo de obtención de cookies y variables de sesión de los exploradores Mozilla
Firefox y Google-Chrome.

- .5 puntos. Módulo para captura de pantalla.
       * Se necesita instalar:
                
            apt-get install imagemagick


- .5 puntos. Módulo captura de video por medio de la cámara web o captura de sonido por
medio del micrófono.
       * Se necesita instalar:
            
             apt-get install streamer

             apt-get install alsa-utils
             
             apt-get install alsa-oss
             
             apt-get install 4l2ucp
             
       *Habilitar modulo:
       
             modprobe snd_pcm_oss


- .5 puntos. Módulo de obtención de contraseñas almacenadas en los exploradores Mozilla Firefox y Google-Chrome.
       * Se necesita instalar:
            
             apt-get install sqlite3


- .5 puntos. Documentación

- 1 puntos. Módulo de keylogger.

- 1 puntos. Implementación de canales cifrados.

       * Se necesita instalar:
            
             apt-get install python-dev 
             
       *Habilitar modulo:
       
             pyCrypto y paramiko

- 1.5 puntos. Módulo de puerta trasera (tráfico cifrado).

- 2 puntos. Módulo de sesión de meterpreter.
       * Se necesita instalar:
                
              kali 



- 2 puntos. Integración cliente/servidor

- 2 puntos. Ocultamiento de procesos y conexiones establecidas.

             apt-get install linux-headers-$(uname -r)
