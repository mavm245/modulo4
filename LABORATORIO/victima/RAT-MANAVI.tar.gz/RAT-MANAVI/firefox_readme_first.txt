Referencias:

~http://www.cafewebmaster.com/howto-readexport-firefox-cookies-linux
~http://linuxfreelancer.com/decoding-firefox-cookies-sqlite-cookies-viewer
~http://stackoverflow.com/questions/1841901/cookie-file-for-google-chrome-unix
~https://hg.cryptobitch.de/firefox-passwords/file/226380cf2849/firefox_passwd.py#l2
~http://unix.stackexchange.com/questions/149525/query-firefox-password-database
~http://www.computershowto.pro/2014/05/import-chrome-or-chromium-passwords-into-firefox/
~http://blog.befreely.net/2011/05/google-chrome-password-export.html
