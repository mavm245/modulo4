//Uso:
$ ./keylogger <tiempo en segundos>
$ ./keylogger 30

-El archivo se crea en /tmp/keylogger.txt

//Bugs:
-Si no se especifica el tiempo manda errores muy feos.

//Referencias:
~https://github.com/mvasquezbec/modulo4
